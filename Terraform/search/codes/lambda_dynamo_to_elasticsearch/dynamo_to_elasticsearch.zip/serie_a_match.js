"use strict";
exports.__esModule = true;
var SerieAMatch = /** @class */ (function () {
    function SerieAMatch(_a) {
        var home = _a.home, away = _a.away, date = _a.date, half_time = _a.half_time, final_score = _a.final_score, season = _a.season;
        this.home = home;
        this.away = away;
        this.date = date;
        this.half_time = half_time;
        this.final_score = final_score;
        this.season = season;
    }
    return SerieAMatch;
}());
exports.SerieAMatch = SerieAMatch;
